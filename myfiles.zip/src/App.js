import "./App.css";
import { useEffect, useState } from "react";
import Input from "./components/Input";
import GroupField from "./components/GroupField";
import SelectField from "./components/SelectField";
import RadioField from "./components/RadioField";
import SwitchField from "./components/SwitchField";
import { useForm } from "react-hook-form";

const App = () => {

  //hook form
  const {register , handleSubmit , watch, getValues , formState : {errors}} = useForm();
  const onsubmit = (data) => {
    console.log(data);
  }



  const [uiSchema, setUiSchema] = useState();
  const [showAdvanced, setShowAdvanced] = useState(false);

  const [responseSchema, setResponseSchema] = useState();

  function isJsonString(str) {
    try {
      JSON.parse(str);
    } catch (e) {
      return false;
    }
    return true;
  }

  function handleSchemaChange(e) {
    if (isJsonString(e.target.value)) {
      setUiSchema(JSON.parse(e.target.value));
    } else {
      console.log("Not proper json");
      setUiSchema(null);
    }
  }

  function handleFormSubmit(e) {
    e.preventDefault();
    var data = new FormData(e.target);
    let formObject = Object.fromEntries(data.entries());
    console.log(formObject);
  }

  useEffect(() => {
    if (uiSchema) {
      // createResponseSchema(uiSchema);
    }
  }, [uiSchema]);
  return (
    <>
      <div className="grid grid-cols-12">
        <div className="col-span-6 border-r border-gray-400">
          <textarea
            placeholder="Paste the UI Schema"
            className="w-full h-screen "
            onChange={(e) => handleSchemaChange(e)}
          ></textarea>
        </div>

        {
          //as soon as i get a ui sce
        }

        {uiSchema && (
          // <form className="col-span-6 p-8" onSubmit={handleFormSubmit}>
            <form className="col-span-6 p-8" onSubmit={handleSubmit(onsubmit)}>
            {uiSchema.map((item, index) => {
              {
                if (item.validate.required) {
                  if (item.uiType == "Input")
                    return <Input key={index} data={item} namefield={item.jsonKey} register = {register}/>;
                  else if (item.uiType == "Group")
                    return <GroupField key={index} data={item} parentJsonKey= {item.jsonKey} register = {register} watch = {watch} getValues = {getValues}/>;
                  else if (item.uiType == "Select")
                    return <SelectField key={index} data={item} namefield={item.jsonKey} register = {register}/>;
                  else if (item.uiType == "Radio")
                    return <RadioField key={index} data={item} namefield={item.jsonKey} register = {register}/>;
                  else if (item.uiType == "Switch")
                    return <SwitchField key={index} data={item} namefield={item.jsonKey} register = {register}/>;
                }
              }
            })}

            {showAdvanced &&
              uiSchema.map((item, index) => {
                {
                  if (item.validate && !item.validate.required) {
                    if (item.uiType == "Input")
                      return <Input key={index} data={item} namefield={item.jsonKey} register={register}/>;
                    else if (item.uiType == "Group")
                      return <GroupField key={index} data={item}  parentJsonKey= {item.jsonKey} register={register} watch = {watch} getValues = {getValues}/>;
                    else if (item.uiType == "Select")
                      return <SelectField key={index} data={item} namefield={item.jsonKey} register={register}/>;
                    else if (item.uiType == "Radio")
                      return <RadioField key={index} data={item} namefield={item.jsonKey} register={register}/>;
                    else if (item.uiType == "Switch")
                      return <SwitchField key={index} data={item} namefield={item.jsonKey} register={register}/>;
                  }
                }
              })}

            <div className="mt-4 mb-2 flex items-center">
              <input
                type="checkbox"
                value={showAdvanced}
                onChange={(e) => setShowAdvanced(!showAdvanced)}
              />
              <h1 className="ml-2">Show advanced options</h1>
            </div>

            <button
              className="bg-gray-800 text-white font-medium rounded-md px-4 py-2 mt-4"
              type="submit"
            >
              Submit Form
            </button>
          </form>
        )}
      </div>
    </>
  );
};

export default App;
