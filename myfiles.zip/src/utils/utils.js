export const createResponseSchema = (uiSchema) => {
    var responseObject = {};

}