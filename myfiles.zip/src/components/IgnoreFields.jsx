import React, { useEffect, useState } from "react";
import Description from "./Description";
import Input from "./Input";
import RadioField from "./RadioField";
import SelectField from "./SelectField";
import GroupField from "./GroupField";
import SwitchField from "./SwitchField";

const IgnoreFields = ({ ignoredFields, namefield, register, watch, getValues }) => {
    const [display, setDisplay] = useState(true);

  //   function checkToDisplay() {
  //     var existingval = document.getElementsByName(data.conditions[0].jsonKey);
  //     if (existingval && existingval[0]) existingval = existingval[0].value;
  //     var resultantstring =
  //       "'" +
  //       String(existingval) +
  //       "'" +
  //       data.conditions[0].op +
  //       "'" +
  //       data.conditions[0].value +
  //       "'";
  //     setDisplay(eval(resultantstring));
  //   }

  console.log(ignoredFields)

    useEffect(() => {
        // obj = ignoredFields.find((item) => {
        //     getValues(item.conditions[0].jsonKey) == 
        // })
    }, [])
  return (
    <>
      {ignoredFields &&
        ignoredFields.map((field, fieldindex) => {
          return field.subParameters.map((item, index) => {
            // console.log(getValues(namefield + "." + field.jsonKey + "." + item.jsonKey))
            if(watch(namefield + "." + field.jsonKey + "." + item.jsonKey) === field.conditions[0].value) console.log("Inside" , field.conditions[0].value);
            if (item.uiType == "Select")
              return (
                <SelectField
                  data={item}
                  register={register}
                  namefield={
                    namefield + "." + field.jsonKey + "." + item.jsonKey
                  }
                  key={index}
                />
              );
            else if (item.uiType == "Input")
              return (
                <Input
                  data={item}
                  register={register}
                  namefield={
                    namefield + "." + field.jsonKey + "." + item.jsonKey
                  }
                  key={index}
                />
              );
            else if (item.uiType == "Switch")
              return (
                <SwitchField
                  data={item}
                  register={register}
                  namefield={
                    namefield + "." + field.jsonKey + "." + item.jsonKey
                  }
                  key={index}
                />
              );
          });
        })}
    </>
  );
};

export default IgnoreFields;
