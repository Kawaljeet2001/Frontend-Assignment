import React from "react";
import Description from "./Description";

const SwitchField = ({ data, namefield , register }) => {
  return (
    <div className="my-2 bg-gray-50  rounded-lg p-6 grid grid-cols-12 w-full">
      <h1 className="col-span-3 font-bold flex items-center">
        {data.label} &nbsp;
        {data.description && <Description desc={data.description} />}
      </h1>

      <input
        type="checkbox"
        // name={namefield}
        {...register(namefield)}
        defaultChecked={data.validate.defaultValue}
      />
    </div>
  );
};

export default SwitchField;
